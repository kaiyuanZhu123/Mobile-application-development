package com.example.country_capital_display_application;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private Handler myHandler = new Handler();
    private RecyclerView recyclerView;
    private SearchView searchView;
    private JSONArray data = null;
    private LinearLayoutManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recyclerview);

        recyclerView = findViewById(R.id.myRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setVisibility(View.INVISIBLE);
        manager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);


        searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                boolean find = false;
                if(data!=null && data.length()!=0){
                    try{
                        for(int i=0;i<data.length();i++){
                            JSONObject jsonObject = data.getJSONObject(i);
                            if(s.equals(jsonObject.getString("country")) || s.equals(jsonObject.getString("capital"))){
                                MoveToPosition(manager, recyclerView ,i+1);
                                find = true;
                            }
                        }
                    } catch (JSONException e){}
                }
                if(!find){
                    Toast.makeText(getApplicationContext(), "no result", Toast.LENGTH_SHORT).show();
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

        findViewById(R.id.myButton).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        downloadData(recyclerView, 1);
                        findViewById(R.id.myRecyclerView).setVisibility(View.VISIBLE);
                    }
                };
                myHandler.post(runnable);
            }
        });
    }

    private class myViewHolder extends RecyclerView.ViewHolder{
        TextView countryView;
        TextView capitalView;

        public myViewHolder(View itemView) {
            super(itemView);
            countryView = itemView.findViewById(R.id.countryView);
            capitalView = itemView.findViewById(R.id.capitalView);
        }
    }
    public class MyAdapter extends RecyclerView.Adapter<myViewHolder>{
        private JSONArray jsonArray;

        MyAdapter(JSONArray data) {
            this.jsonArray = data;
        }

        @Override
        public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).
                    inflate(R.layout.item_recyclerview, parent, false);
            return new myViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
            try {
                JSONObject jsonObject = jsonArray.getJSONObject(position);
                holder.countryView.setText(jsonObject.getString("country"));
                holder.capitalView.setText(jsonObject.getString("capital"));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }

        @Override
        public int getItemCount() {
            return jsonArray.length();
        }
    }
    private void downloadData(RecyclerView recyclerView, int page){
        String url = "https://studio.mg/api-country/index.php?page=" + page;
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            data = response.getJSONArray("data");
                            recyclerView.setAdapter(new MyAdapter(data));
                        }catch (JSONException e){
                            e.printStackTrace();
                        }
                        Toast.makeText(getApplicationContext(), "Download completed", Toast
                                .LENGTH_SHORT).show();
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        showDownloadFailedDialog();
                    }
                });
        queue.add(jsonObjectRequest);
    }
    private void showDownloadFailedDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Download failed...Please check your network settings");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {}
        });
        builder.show();
    }

    private void MoveToPosition(LinearLayoutManager manager, RecyclerView mRecyclerView ,int n) {
        //manager.scrollToPositionWithOffset(n, 0);
        //manager.setStackFromEnd(true);
        int firstItem = manager.findFirstVisibleItemPosition();
        int lastItem = manager.findLastVisibleItemPosition();
        if (n <= firstItem) {
            mRecyclerView.scrollToPosition(n);
        } else if (n <= lastItem) {
            int top = mRecyclerView.getChildAt(n - firstItem).getTop();
            mRecyclerView.scrollBy(0, top);
        } else {
            mRecyclerView.scrollToPosition(n);
        }
    }
}
package com.example.assignmenttrackerpro;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.assignmenttrackerpro.databinding.ActivityNetworkerrorBinding;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

public class NetErrorActivity extends AppCompatActivity {
    private static boolean haveNet = false;
    private Button button;
    private ProgressBar progressBar;
    private static final int START = 1;
    private static final int COMPLETED = 0;
    private Handler handler;

    @SuppressLint("HandlerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_networkerror);

        progressBar = findViewById(R.id.progressBarNet);
        progressBar.setVisibility(View.GONE);

        handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == COMPLETED) {
                    progressBar.setVisibility(View.GONE);
                    progressBar.setIndeterminate(false);
                }
                else if(msg.what == START){
                    progressBar.setVisibility(View.VISIBLE);
                }
            }
        };

        button = findViewById(R.id.refreshBtnNet);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                button.setEnabled(false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        checkNetwork();
                    }
                }).start();
            }
        });
    }

    private void goBack(){
        finish();
    }

    private void checkNetwork(){
        Message message = new Message();
        message.what = START;
        handler.sendMessage(message);
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.POST, "https://www.baidu.com",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        haveNet = true;
                        button.setEnabled(true);
                        Message message = new Message();
                        message.what = COMPLETED;
                        handler.sendMessage(message);
                        goBack();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(NetErrorActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                        Message message = new Message();
                        message.what = COMPLETED;
                        handler.sendMessage(message);
                        button.setEnabled(true);
                    }
                });
        request.setShouldCache(false);
        queue.add(request);
    }
}

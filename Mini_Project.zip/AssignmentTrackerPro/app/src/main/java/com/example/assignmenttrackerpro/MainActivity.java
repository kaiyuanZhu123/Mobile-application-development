package com.example.assignmenttrackerpro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.assignmenttrackerpro.databinding.ActivityMainBinding;
import com.example.assignmenttrackerpro.ui.agora.MessagePost;
import com.google.android.material.bottomnavigation.BottomNavigationItemView;
import com.google.android.material.bottomnavigation.BottomNavigationMenuView;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import me.pushy.sdk.Pushy;
import me.pushy.sdk.util.exceptions.PushyException;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    public static List<MessagePost> messageList = new ArrayList<>();

    public static boolean refreshedMessage = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Pushy.listen(this);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_report, R.id.navigation_assignmentDetails, R.id.navigation_agora)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);

        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.navigation_Report) {
                    navController.navigate(R.id.navigation_report);
                    return true;
                } else if (itemId == R.id.navigation_AssignmentDetails) {
                    navController.navigate(R.id.navigation_assignmentDetails);
                    return true;
                } else if (itemId == R.id.navigation_Agora) {
                    navController.navigate(R.id.navigation_agora);
                    return true;
                }
                return false;
            }
        });

        checkNewMessage();
        checkRefreshedMessage();
    }

    public void getPushyToken() throws PushyException {
        if (!Pushy.isRegistered(getApplicationContext())) {
            new RegisterForPushNotificationsAsync(this).execute();
            Pushy.subscribe("news", getApplicationContext());
        }
    }

    private class RegisterForPushNotificationsAsync extends AsyncTask<Void, Void, Object> {
        Activity mActivity;

        public RegisterForPushNotificationsAsync(Activity activity) {
            this.mActivity = activity;
        }

        protected Object doInBackground(Void... params) {
            try {
                // Register the device for notifications (replace MainActivity with your Activity class name)
                String deviceToken = Pushy.register(MainActivity.this);

                // Registration succeeded, log token to logcat
                Log.d("Pushy", "Pushy device token: " + deviceToken);

                // Send the token to your backend server via an HTTP GET request
                new URL("https://{YOUR_API_HOSTNAME}/register/device?token=" + deviceToken).openConnection();

                // Provide token to onPostExecute()
                return deviceToken;
            }
            catch (Exception exc) {
                // Registration failed, provide exception to onPostExecute()
                return exc;
            }
        }

        @Override
        protected void onPostExecute(Object result) {
            String message;

            // Registration failed?
            if (result instanceof Exception) {
                // Log to console
                Log.e("Pushy", result.toString());

                // Display error in alert
                message = ((Exception) result).getMessage();
            }
            else {
                message = "Pushy device token: " + result.toString() + "\n\n(copy from logcat)";
            }

            // Registration succeeded, display an alert with the device token
            new android.app.AlertDialog.Builder(this.mActivity)
                    .setTitle("Pushy")
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok, null)
                    .show();
        }
    }

    public static void sendSamplePush() {
        // Prepare list of target device tokens
        List<String> deviceTokens = new ArrayList<>();

        // Add your device tokens here
        deviceTokens.add("6502b6e7557ed81513a077");

        // Convert to String[] array
        String[] to = deviceTokens.toArray(new String[deviceTokens.size()]);

        // Optionally, send to a publish/subscribe topic instead
        // String to = '/topics/news';

        // Set payload (any object, it will be serialized to JSON)
        Map<String, String> payload = new HashMap<>();

        // Add "message" parameter to payload
        payload.put("message", "Hello World!");

        // iOS notification fields
        Map<String, Object> notification = new HashMap<>();

        notification.put("badge", 1);
        notification.put("sound", "ping.aiff");
        notification.put("title", "Test Notification");
        notification.put("body", "Hello World \u270c");

        // Prepare the push request
        /*
        PushyAPI.PushyPushRequest push = new PushyAPI.PushyPushRequest(payload, to, notification);

        try {
            // Try sending the push notification
            PushyAPI.sendPush(push);
        }
        catch (Exception exc) {
            // Error, print to console
            System.out.println(exc.toString());
        }

         */
    }

    @SuppressLint("RestrictedApi")
    public void displayItemNum(final int mCount) {
        try {
            BottomNavigationView mBottomNavigationView = findViewById(R.id.nav_view);
            final BottomNavigationMenuView menuView = (BottomNavigationMenuView) mBottomNavigationView.getChildAt(0);
            final View mTab = menuView.getChildAt(2);
            final BottomNavigationItemView itemView = (BottomNavigationItemView) mTab;
            View mBadge = itemView.getChildAt(2);
            if (mBadge == null) {
                //避免重复添加创建
                mBadge = LayoutInflater.from(mBottomNavigationView.getContext()).inflate(R.layout.bottom_bar_item_badge, menuView, false);
                itemView.addView(mBadge);
            }
            final TextView mTv = mBadge.findViewById(R.id.tv_msg_count);
            if (mCount <= 0) {
                mTv.post(new Runnable() {
                    @Override
                    public void run() {
                        mTv.setVisibility(View.GONE);
                        mTv.setText(String.format("%s", mCount));
                    }
                });
            } else {
                mTv.post(new Runnable() {
                    @Override
                    public void run() {
                        mTv.setVisibility(View.VISIBLE);
                        if (mCount > 99) {
                            mTv.setText(String.format("%s+", 99));
                        } else {
                            mTv.setText(String.format("%s", mCount));
                        }
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void checkNewMessage(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Log.d("----------------", "check update");
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, getString(R.string.getMessage),
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONObject jsonObject = new JSONObject(response);
                                        JSONArray jsonArray = jsonObject.getJSONArray("messages");
                                        if (jsonArray.length() > messageList.size()) {
                                            displayItemNum(jsonArray.length() - messageList.size());
                                            refreshedMessage = false;
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    error.printStackTrace();
                                }
                            });
                    RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                    stringRequest.setShouldCache(false);
                    requestQueue.add(stringRequest);
                    try {
                        Thread.currentThread().sleep(60000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }).start();
    }

    private void checkRefreshedMessage(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    if(refreshedMessage){
                        displayItemNum(0);
                    }
                    try {
                        Thread.currentThread().sleep(1000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }).start();
    }
}
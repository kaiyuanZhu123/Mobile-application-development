package com.example.assignmenttrackerpro.ui.assignmentdetails;

import android.Manifest;
import android.app.Activity;
import android.app.Application;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.assignmenttrackerpro.AssignmentDetails;
import com.example.assignmenttrackerpro.R;
import com.example.assignmenttrackerpro.databinding.FragmentAssignmentdetailsBinding;
import com.google.android.material.snackbar.Snackbar;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class AssignmentDetailsFragment extends Fragment{
    private FragmentAssignmentdetailsBinding binding;
    private RecyclerView mRecyclerView;
    private AssignmentAdapter mAssignmentAdapter;
    private ProgressBar progressBar;
    private RequestQueue queue;
    private JSONArray jsonArrayOfAssignment;
    private List<AssignmentDetails> assignmentDetails;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        AssignmentDetailsViewModel homeViewModel =
                new ViewModelProvider(this).get(AssignmentDetailsViewModel.class);
        binding = FragmentAssignmentdetailsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        assignmentDetails = new ArrayList<>();

        progressBar = binding.progressBar;
        progressBar.setVisibility(View.GONE);

        mRecyclerView = binding.assignmentRecyclerView;
        mAssignmentAdapter = new AssignmentAdapter(assignmentDetails);
        mRecyclerView.setAdapter(mAssignmentAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));

        queue = Volley.newRequestQueue(this.getContext());

        initializeData();

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private class AssignmentAdapter extends RecyclerView.Adapter<AssignmentDetailsFragment.AssignmentAdapter.AssignmentViewHolder> {
        private List<AssignmentDetails> mAssignmentList;
        public AssignmentAdapter(List<AssignmentDetails> AssignmentList) {
            mAssignmentList = AssignmentList;
        }
        @NonNull
        @Override
        public AssignmentDetailsFragment.AssignmentAdapter.AssignmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int
                viewType) {
            View view =
                    LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recycler_assignment, parent, false);
            return new AssignmentDetailsFragment.AssignmentAdapter.AssignmentViewHolder(view);
        }
        @Override
        public void onBindViewHolder(@NonNull AssignmentDetailsFragment.AssignmentAdapter.AssignmentViewHolder holder, int
                position) {
            AssignmentDetails assignment = mAssignmentList.get(position);
            holder.bind(assignment);
        }
        @Override
        public int getItemCount() {
            return mAssignmentList.size();
        }
        class AssignmentViewHolder extends RecyclerView.ViewHolder {
            private TextView mFileNameTextView;
            private TextView mUrlTextView;
            private Button checkPdfBtn;
            public AssignmentViewHolder(@NonNull View itemView) {
                super(itemView);
                mFileNameTextView = itemView.findViewById(R.id.assignment_filename);
                mUrlTextView = itemView.findViewById(R.id.assignment_url);
                checkPdfBtn = itemView.findViewById(R.id.btn_checkPdf);
            }
            public void bind(AssignmentDetails assignment) {
                mFileNameTextView.setText(assignment.getFileName());
                mUrlTextView.setText("url: " + assignment.getUrl());
                checkPdfBtn.setOnClickListener(new CheckPdfBtnListener("https://studio.mg/submission2023/assignments/" + mFileNameTextView.getText()));
            }
        }
        public void updateData(List<AssignmentDetails> AssignmentList) {
            mAssignmentList = AssignmentList;
            notifyDataSetChanged();
        }
        public void setAssignmentList(List<AssignmentDetails> AssignmentList) {
            mAssignmentList = AssignmentList;
            notifyDataSetChanged();
        }
    }

    private void initializeData(){
        JsonArrayRequest jsonArrayRequestOfAssignment = new JsonArrayRequest(Request.Method.GET,
                getString(R.string.assignmentDetailsUrl), null, response -> {
            jsonArrayOfAssignment = response;
            assignmentDetails = parseJsonOfAssignmentDetails(jsonArrayOfAssignment);
            mAssignmentAdapter.setAssignmentList(assignmentDetails);
            mAssignmentAdapter.updateData(assignmentDetails);
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                        showDownloadFailedDialog("assignmentDetails");
            }
        });
        jsonArrayRequestOfAssignment.setShouldCache(true);
        queue.add(jsonArrayRequestOfAssignment);
    }

    private List<AssignmentDetails> parseJsonOfAssignmentDetails(JSONArray jsonArray) {
        List<AssignmentDetails> assignmentList = new ArrayList<>();
        try {
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject reportObject = jsonArray.getJSONObject(i);
                String filename = reportObject.getString("filename");
                String url = reportObject.getString("url");
                assignmentList.add(new AssignmentDetails(filename, url));
            }
        } catch (JSONException e) {
            Snackbar.make(this.getActivity().findViewById(android.R.id.content), "There was an error " +
                    "loading the data. Please try again later.", Snackbar.LENGTH_LONG).show();
            e.printStackTrace();
            Log.e("JSON", "Error parsing JSON data", e);
        }
        return assignmentList;
    }

    private void showDownloadFailedDialog(String target){
        AlertDialog.Builder builder = new AlertDialog.Builder(this.getContext());
        builder.setMessage("Failed to download " + target + ". It seems like there is no internet " +
                "connection. Please check your network settings and try again.");
        builder.setPositiveButton("OK", (dialogInterface, i) -> {});
        builder.show();
    }

    public void openPDF(File file) {
        if (file.exists()) {
            Intent openFileIntent = new Intent(Intent.ACTION_VIEW);
            Uri fileUri = FileProvider.getUriForFile(this.getContext(), this.getContext().getPackageName() + ".provider", file);
            openFileIntent.setDataAndType(fileUri, "application/pdf"); // Later: Replace "application/pdf" with the appropriate MIME type if not PDF
            openFileIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Log.d("OPEN_PATH", "Open Path: " + file.getAbsolutePath());
            this.getContext().startActivity(Intent.createChooser(openFileIntent, "Open file with"));
        }
    }

    public void downFile(String stringUrl){
        int REQUEST_EXTERNAL_STORAGE = 1;
        String[] PERMISSIONS_STORAGE = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        ActivityCompat.requestPermissions(
                getActivity(),
                PERMISSIONS_STORAGE,
                REQUEST_EXTERNAL_STORAGE
        );
        try {
            URL url = new URL(stringUrl);
            HttpURLConnection connection = (HttpURLConnection)
                    url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setUseCaches(true);
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(20000);
            //实现连接
            connection.connect();
            Log.d("开始下载", "开始下载");
            if (connection.getResponseCode() == 200) {
                String path = Environment.getExternalStorageDirectory()
                        + "/download/";
                String[] name = stringUrl.split("/");
                path = path + name[name.length - 1];
                File file = new File(path);
                Log.d("文件存储路径", path);
                if(!file.exists()){
                    //以下为下载操作
                    InputStream is = connection.getInputStream();
                    byte[] arr = new byte[1];
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    BufferedOutputStream bos = new BufferedOutputStream(baos);
                    int n = is.read(arr);
                    while (n > 0) {
                        bos.write(arr);
                        n = is.read(arr);
                    }
                    bos.close();
                    FileOutputStream fos = new FileOutputStream(file);
                    fos.write(baos.toByteArray());
                    fos.close();
                    //关闭网络连接
                    connection.disconnect();
                }
                progressBar.post(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setVisibility(View.GONE);
                        progressBar.setIndeterminate(false);
                    }
                });
                openPDF(file);//打开PDF文件
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private class CheckPdfBtnListener implements View.OnClickListener{
        String url;

        CheckPdfBtnListener(String url){
            this.url = url;
        }

        @Override
        public void onClick(View view) {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setIndeterminate(true);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Looper.prepare();
                    downFile(url);
                    Looper.loop();
                }
            }).start();
        }
    }
}
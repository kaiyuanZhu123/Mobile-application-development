package com.example.assignmenttrackerpro.ui.agora;

import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.assignmenttrackerpro.MainActivity;
import com.example.assignmenttrackerpro.R;
import com.example.assignmenttrackerpro.databinding.FragmentAgoraBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AgoraFragment extends Fragment{
    private FragmentAgoraBinding binding;
    private RecyclerView recyclerView;
    private List<MessagePost> messageList;
    private MessageAdapter messageAdapter;
    private ProgressBar progressBar;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentAgoraBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        messageList = new ArrayList<>();
        messageAdapter = new MessageAdapter(messageList, this.getContext(), Settings.Secure.ANDROID_ID);
        messageAdapter.setOnItemLongClickListener(new MessageAdapter.OnRecyclerItemLongListener() {
            @Override
            public void onItemLongClick(View view, int position) {
                Log.d("-------", "长按");
            }
        });

        recyclerView = binding.newsList;
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.setAdapter(messageAdapter);

        progressBar = binding.progressBar;
        progressBar.setVisibility(View.GONE);

        RefreshData();

        binding.refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RefreshData();
            }
        });

        binding.sendMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = String.valueOf(binding.editMessage.getText());
                MessagePost messagePost = new MessagePost(Settings.Secure.ANDROID_ID, "YOUR_IP_LOCATION",
                        String.valueOf(getDeviceTime()), message);
                if(!message.equals("")){
                    sendMessage(messagePost);
                }
                else{
                    Toast.makeText(getContext(), "Please input your message", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void RefreshData(){
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, getString(R.string.getMessage),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String status;
                        try{
                            JSONObject jsonObject = new JSONObject(response);
                            status = jsonObject.getString("status");
                            JSONArray jsonArray = jsonObject.getJSONArray("messages");
                            messageList.clear();
                            for(int i=0;i<jsonArray.length();i++){
                                JSONObject jsonMessage = (JSONObject) jsonArray.get(i);
                                messageList.add(new MessagePost(jsonMessage.getString("device_id"), jsonMessage.getString("ip_location"),
                                        jsonMessage.getString("timer_device"), jsonMessage.getString("timer_server"),
                                        jsonMessage.getString("message")));
                            }
                            messageAdapter.notifyDataSetChanged();
                            MainActivity.messageList = messageList;
                            MainActivity.refreshedMessage = true;
                        }catch (JSONException e){
                            e.printStackTrace();
                        }
                        setLastUpdateDate();
                        scrollToLastItem();
                        progressBar.setVisibility(View.GONE);
                        progressBar.setIndeterminate(false);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
                        progressBar.setVisibility(View.GONE);
                        progressBar.setIndeterminate(false);
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(this.getContext());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void sendMessage(MessagePost message){
        if(message.getMessage().startsWith("@robot ")){
            sendMessageToServer(message);
            requestRobot(message.getMessage().substring(6));
        }else{
            sendMessageToServer(message);
        }
    }

    private void sendMessageToServer(MessagePost message){
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);
        binding.sendMessage.setEnabled(false); // Disable the button

        StringRequest stringRequest = new StringRequest(Request.Method.POST, getString(R.string.postMessage),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String teacher_message = jsonObject.getString("teacher_message");
                            if(status.equals("success")){
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        RefreshData();
                                    }
                                }, 2000);
                                Toast.makeText(getActivity(), teacher_message, Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(getActivity(), jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        }catch (JSONException e){
                            e.printStackTrace();
                        }
                        binding.editMessage.setText("");
                        binding.sendMessage.setEnabled(true);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
                        binding.sendMessage.setEnabled(true);
                        progressBar.setVisibility(View.GONE);
                        progressBar.setIndeterminate(false);
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("device_id", message.getDevice_id());
                params.put("ip_location", message.getIp_location());
                params.put("timer_device", message.getTimer_device());
                params.put("message", message.getMessage());
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void scrollToLastItem() {
        LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        if (layoutManager != null) {
            layoutManager.scrollToPosition(messageList.size() - 1);
        }
    }

    private void setLastUpdateDate() {
        TextView lastUpdateTextView = binding.lastUpdateTextView;
        String currentDateTimeString =
                DateFormat.getDateTimeInstance().format(new Date());
        lastUpdateTextView.setText("Last update: " + currentDateTimeString);
    }

    private void requestRobot(String message) {
        try{
            StringRequest stringRequest = new StringRequest(Request.Method.GET, getString(R.string.robotapi)
                    + "?key=free&appid=0&msg=" + URLEncoder.encode(message, "UTF-8"),
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Log.d("response", response);
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                String robotResponse = jsonObject.getString("content");
                                sendMessageToServer(new MessagePost("robot", "YOUR_IP_LOCATION", String.valueOf(getDeviceTime()), robotResponse));
                            } catch (JSONException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            error.printStackTrace();
                        }
                    });
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            stringRequest.setShouldCache(false);
            requestQueue.add(stringRequest);
        }catch (UnsupportedEncodingException e){
            e.printStackTrace();
        }
    }

    public long getDeviceTime() {
        return System.currentTimeMillis() / 1000;
    }
}
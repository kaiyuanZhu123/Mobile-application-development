package com.example.assignmenttrackerpro.ui.agora;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AgoraViewModel extends ViewModel{
    private final MutableLiveData<String> mText;

    public AgoraViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is agora fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}

package com.example.assignmenttrackerpro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ProgressBar progressBar;
    private Spinner resourceSpinner;
    private Spinner statusSpinner;
    private RecyclerView mRecyclerView;
    private ReportAdapter mReportAdapter;
    private ImageButton refreshBtn;
    private RequestQueue queue;
    private JSONObject jsonObjectOfAssignment;
    private List<Assignment> Assignments;
    private JSONObject jsonObjectOfReport;
    private List<Report> reportList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_activity_assignment);
        setTitle(getString(R.string.mainActivityTitle));

        Assignments = new ArrayList<>();
        reportList = new ArrayList<>();

        progressBar = findViewById(R.id.progressBar);

        resourceSpinner = findViewById(R.id.sourceSelectionSpinner);
        ArrayAdapter<Assignment> adapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item, Assignments);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        resourceSpinner.setAdapter(adapter);
        resourceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                if(Assignments!=null){
                    updateRecyclerView(Assignments.get(position).getId());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        statusSpinner = findViewById(R.id.statusSelectionSpinner);
        ArrayAdapter<String> statusSpinnerAdapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.status));
        statusSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(statusSpinnerAdapter);
        statusSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                if(reportList!=null) {
                    List<Report> filteredReports = filterReportsByStatus(reportList,
                            getResources().getStringArray(R.array.status)[position]);
                    mReportAdapter.setReportList(filteredReports);
                    mReportAdapter.updateData(filteredReports);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}
        });

        mRecyclerView = findViewById(R.id.reportRecyclerView);
        mReportAdapter = new ReportAdapter(new ArrayList<>());
        mRecyclerView.setAdapter(mReportAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        refreshBtn = findViewById(R.id.refreshBtn);
        refreshBtn.setOnClickListener(view -> refreshData());

        queue = Volley.newRequestQueue(this);

        initializeData();
    }

    private static class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ReportViewHolder> {
        private List<Report> mReportList;
        public ReportAdapter(List<Report> reportList) {
            mReportList = reportList;
        }
        @NonNull
        @Override
        public ReportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int
                viewType) {
            View view =
                    LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recycler_report, parent, false);
            return new ReportViewHolder(view);
        }
        @Override
        public void onBindViewHolder(@NonNull ReportViewHolder holder, int
                position) {
            Report report = mReportList.get(position);
            holder.bind(report);
        }
        @Override
        public int getItemCount() {
            return mReportList.size();
        }
        class ReportViewHolder extends RecyclerView.ViewHolder {
            private TextView mNameTextView;
            private TextView mIdTextView;
            private TextView mSizeTextView;
            private TextView mStatusTextView;
            public ReportViewHolder(@NonNull View itemView) {
                super(itemView);
                mNameTextView = itemView.findViewById(R.id.nameTextView);
                mIdTextView = itemView.findViewById(R.id.idTextView);
                mSizeTextView = itemView.findViewById(R.id.sizeTextView);
                mStatusTextView = itemView.findViewById(R.id.statusTextView);
            }
            public void bind(Report report) {
                mNameTextView.setText(report.getName());
                mIdTextView.setText(report.getId());
                mSizeTextView.setText("Size: " + report.getSize());
                mStatusTextView.setText("Status: " + report.getStatus());
            }
        }
        public void updateData(List<Report> reportList) {
            mReportList = reportList;
            notifyDataSetChanged();
        }
        public void setReportList(List<Report> reportList) {
            mReportList = reportList;
            notifyDataSetChanged();
        }
    }

    private List<Report> parseJsonOfReport(JSONObject jsonObject) {
        List<Report> reportList = new ArrayList<>();
        try {
            JSONArray jsonArray = jsonObject.getJSONArray("reports");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject reportObject = jsonArray.getJSONObject(i);
                String name = reportObject.getString("name");
                String id = reportObject.getString("id");
                String size = reportObject.getString("size");
                String status = removeLeadingAndTrailingNewLines(reportObject.getString("status"));
                reportList.add(new Report(name, id, size, status));
            }
        } catch (JSONException e) {
            Snackbar.make(findViewById(android.R.id.content), "There was an error " +
                    "loading the data. Please try again later.", Snackbar.LENGTH_LONG).show();
            e.printStackTrace();
            Log.e("JSON", "Error parsing JSON data", e);
        }
        return reportList;
    }

    private List<Assignment> parseJsonOfAssignment(JSONObject jsonObject) {
        List<Assignment> assignmentList = new ArrayList<>();
        try {
            JSONArray jsonArray = jsonObject.getJSONArray("assignments");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject reportObject = jsonArray.getJSONObject(i);
                String name = reportObject.getString("name");
                String id = reportObject.getString("id");
                assignmentList.add(new Assignment(name, id));
            }
        } catch (JSONException e) {
            Snackbar.make(findViewById(android.R.id.content), "There was an error " +
                    "loading the data. Please try again later.", Snackbar.LENGTH_LONG).show();
            e.printStackTrace();
            Log.e("JSON", "Error parsing JSON data", e);
        }
        return assignmentList;
    }

    private void updateRecyclerView(String target) {
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);
        JsonObjectRequest jsonObjectRequestOfReport = new JsonObjectRequest(Request.Method.GET,
                getString(R.string.reportUrl) + target, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        jsonObjectOfReport = response;
                        reportList = parseJsonOfReport(jsonObjectOfReport);
                        for(int i=0;i<reportList.size();i++){
                        }
                        List<Report> filteredReports = filterReportsByStatus(reportList, statusSpinner.getSelectedItem().toString());
                        mReportAdapter.setReportList(filteredReports);
                        mReportAdapter.updateData(filteredReports);
                        progressBar.setVisibility(View.GONE);
                        progressBar.setIndeterminate(false);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                        progressBar.setIndeterminate(false);
                        showDownloadFailedDialog("report");
                    }
                });
        jsonObjectRequestOfReport.setShouldCache(false);
        queue.add(jsonObjectRequestOfReport);
    }

    private String removeLeadingAndTrailingNewLines(String str) {
        return str == null || str.isEmpty() ? str :
                str.replaceAll("(^\\n+|\\n+$)", "");
    }

    private void setLastUpdateDate() {
        TextView lastUpdateTextView = findViewById(R.id.lastUpdateTextView);
        String currentDateTimeString =
                DateFormat.getDateTimeInstance().format(new Date());
        lastUpdateTextView.setText("Last update: " + currentDateTimeString);
    }

    private void initializeData(){
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);
        JsonObjectRequest jsonObjectRequestOfAssignment = new JsonObjectRequest(Request.Method.GET,
                getString(R.string.assignmentUrl), null, response -> {
                    jsonObjectOfAssignment = response;
                    Assignments = parseJsonOfAssignment(jsonObjectOfAssignment);
                    ArrayAdapter<Assignment> adapter = new ArrayAdapter<>(getApplicationContext(),
                            android.R.layout.simple_spinner_dropdown_item, Assignments);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    resourceSpinner.setAdapter(adapter);
                    setLastUpdateDate();
                progressBar.setVisibility(View.GONE);
                progressBar.setIndeterminate(false);
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                        progressBar.setIndeterminate(false);
                        showDownloadFailedDialog("assignment");
                    }
                });
        jsonObjectRequestOfAssignment.setShouldCache(false);
        queue.add(jsonObjectRequestOfAssignment);
    }

    private void refreshData(){
        int currentAssignment = resourceSpinner.getSelectedItemPosition();
        int currentStatus = statusSpinner.getSelectedItemPosition();
        JsonObjectRequest jsonObjectRequestOfAssignment = new JsonObjectRequest(Request.Method.GET, getString(R.string.assignmentUrl), null,
                response -> {
                    jsonObjectOfAssignment = response;
                    Assignments = parseJsonOfAssignment(jsonObjectOfAssignment);
                    ArrayAdapter<Assignment> adapter = new ArrayAdapter<>(getApplicationContext(),
                            android.R.layout.simple_spinner_dropdown_item, Assignments);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    resourceSpinner.setAdapter(adapter);
                    resourceSpinner.setSelection(currentAssignment);
                    statusSpinner.setSelection(currentStatus);
                    setLastUpdateDate();
                },
                error -> showDownloadFailedDialog("assignment"));
        queue.add(jsonObjectRequestOfAssignment);
    }

    private void showDownloadFailedDialog(String target){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Failed to download " + target + ". It seems like there is no internet " +
                "connection. Please check your network settings and try again.");
        builder.setPositiveButton("OK", (dialogInterface, i) -> {});
        builder.show();
    }

    List<Report> filterReportsByStatus(List<Report> reports, String status){
        if(status.equals("All")){
            return reports;
        }
        else{
            List<Report> filteredLList = new ArrayList<>();
            for(int i = 0;i < reports.size();i++){
                if(reports.get(i).getStatus().equals(status)){
                    filteredLList.add(reports.get(i));
                }
            }
            return filteredLList;
        }
    }
}
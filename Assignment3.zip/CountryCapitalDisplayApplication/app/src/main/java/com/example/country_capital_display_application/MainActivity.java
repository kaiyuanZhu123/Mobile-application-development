package com.example.country_capital_display_application;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DownloadManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private String inputString = "[{\"country\":\"Afghanistan\",\"capital\":\"Kabul\"},{\"country\":\"Albania\",\"capital\":\"Tirana\"}," +
            "{\"country\":\"Algeria\",\"capital\":\"Algiers\"},{\"country\":\"Andorra\",\"capital\":\"Andorra la Vella\"}," +
            "{\"country\":\"Angola\",\"capital\":\"Luanda\"},{\"country\":\"Antigua and Barbuda\",\"capital\":\"Saint John's\"}," +
            "{\"country\":\"Argentina\",\"capital\":\"Buenos Aires\"},{\"country\":\"Armenia\",\"capital\":\"Yerevan\"}," +
            "{\"country\":\"Australia\",\"capital\":\"Canberra\"},{\"country\":\"Austria\",\"capital\":\"Vienna\"}," +
            "{\"country\":\"Azerbaijan\",\"capital\":\"Baku\"},{\"country\":\"Bahamas\",\"capital\":\"Nassau\"}," +
            "{\"country\":\"Bahrain\",\"capital\":\"Manama\"},{\"country\":\"Bangladesh\",\"capital\":\"Dhaka\"}," +
            "{\"country\":\"Barbados\",\"capital\":\"Bridgetown\"},{\"country\":\"Belarus\",\"capital\":\"Minsk\"}," +
            "{\"country\":\"Belgium\",\"capital\":\"Brussels\"},{\"country\":\"Belize\",\"capital\":\"Belmopan\"}," +
            "{\"country\":\"Benin\",\"capital\":\"Porto-Novo\"},{\"country\":\"Bhutan\",\"capital\":\"Thimphu\"}]";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recyclerview);

        RecyclerView recyclerView = findViewById(R.id.myRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //recyclerView.setAdapter(new MyAdapter(inputString));

        recyclerView.setVisibility(View.INVISIBLE);

        findViewById(R.id.myButton).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                downloadData(recyclerView, 1);
                Log.d("Tag","download");
                findViewById(R.id.myRecyclerView).setVisibility(View.VISIBLE);
            }
        });
    }

    private class myViewHolder extends RecyclerView.ViewHolder{
        TextView countryView;
        TextView capitalView;

        public myViewHolder(View itemView) {
            super(itemView);
            countryView = itemView.findViewById(R.id.countryView);
            capitalView = itemView.findViewById(R.id.capitalView);
        }
    }

    public class MyAdapter extends RecyclerView.Adapter<myViewHolder>{
        private JSONArray jsonArray;

        MyAdapter(JSONArray data) {
            this.jsonArray = data;
        }

        @Override
        public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).
                    inflate(R.layout.item_recyclerview, parent, false);
            return new myViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
            try {
                JSONObject jsonObject = jsonArray.getJSONObject(position);
                holder.countryView.setText(jsonObject.getString("country"));
                holder.capitalView.setText(jsonObject.getString("capital"));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }

        @Override
        public int getItemCount() {
            return jsonArray.length();
        }
    }

    private void downloadData(RecyclerView recyclerView, int page){
        String url = "https://studio.mg/api-country/index.php?page=" + page;
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("tag","response");
                        try {
                            JSONArray data = response.getJSONArray("data");
                            Log.d("TAG", "json");
                            recyclerView.setAdapter(new MyAdapter(data));
                        }catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error downing data", Toast
                                .LENGTH_SHORT).show();
                        Log.d("TAG", "Error downing data : " + error);
                    }
                });
        queue.add(jsonObjectRequest);
    }
}
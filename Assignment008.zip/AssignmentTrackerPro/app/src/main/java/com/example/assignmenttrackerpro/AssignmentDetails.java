package com.example.assignmenttrackerpro;

public class AssignmentDetails {
    private String filename;
    private String url;

    public AssignmentDetails(String filename, String url) {
        this.filename = filename;
        this.url = url;
    }
    public String getFileName() {
        return filename;
    }
    public String getUrl() {
        return url;
    }

    @Override
    public String toString(){
        return filename + " " + url;
    }
}

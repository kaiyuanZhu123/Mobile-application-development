package com.example.assignmenttrackerpro;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    private Button loginBtn;
    private TextView inputIDView;
    private TextView inputEmailView;
    private Dialog mDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        inputIDView = findViewById(R.id.editCQUID);
        inputEmailView = findViewById(R.id.editPassword);

        loginBtn = findViewById(R.id.login_submit_btn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ID = inputIDView.getText().toString();
                String Email = inputEmailView.getText().toString();
                if (ID.equals("") || Email.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please input the information", Toast.LENGTH_SHORT).show();
                } else {
                    String androidId = Settings.System.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                    CreateUserAccount(ID, Email, androidId);
                }
            }
        });
    }

    private void CreateUserAccount(String CQUID, String Email, String deviceID) {
        if (!CQUID.equals("") && !Email.equals("")) {
            Log.d("infor inside ", CQUID + "   " + Email + "   " + deviceID);
            JSONObject data = new JSONObject();
            String url = "https://studio.mg/submission2023/app-access-validation.php";
            RequestQueue queue = Volley.newRequestQueue(this);
            StringRequest request = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Log.d("response:  ", response);
                            parseResponseOfRegister(response, CQUID, Email, deviceID);
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("student_id", CQUID);
                    params.put("email", Email);
                    params.put("device", deviceID);
                    return params;
                }
            };
            request.setShouldCache(false);
            queue.add(request);
        }
    }

    private void parseResponseOfRegister(String response , String student_id, String email, String device) {
        try{
            JSONObject json = new JSONObject(response);
            if(json.has("error")){
                String errorMessage = json.getString("error");
                Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
            }else{
                boolean activated = json.getBoolean("activated");
                if(activated){
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                else{
                    String passcode = json.getString("passcode");
                    String verification_link = buildVerificationLink(student_id, passcode, device, email);
                    showDialogForAccountValidation(student_id, email,passcode, verification_link);
                }
            }

        }catch (JSONException e){
            e.printStackTrace();
        }
    }

    private String buildVerificationLink(String studentId, String passcode, String deviceId, String email) {
        return "https://studio.mg/submission2023/verify.php?" +
                "student_id=" + studentId +
                "&passcode=" + passcode +
                "&device=" + deviceId +
                "&email=" + email;
    }

    private void showDialogForAccountValidation(String studentId, String email, String passcode, String verificationLink) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Passcode");

        View viewInflated = LayoutInflater.from(this)
                .inflate(R.layout.dialog_enter_passcode, (ViewGroup) findViewById(android.R.id.content), false);

        // Set up the input
        final EditText input = viewInflated.findViewById(R.id.passcode_input);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        builder.setView(viewInflated);

        viewInflated.findViewById(R.id.validate_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String passcodeEntered = input.getText().toString();
                if (passcodeEntered.equals(passcode)) {
                    sendVerificationLink(studentId, email, verificationLink);
                } else {
                    Toast.makeText(getApplicationContext(), "Passcode is not correct", Toast.LENGTH_SHORT).show();
                }
                mDialog.dismiss();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        mDialog = builder.show();
    }

    private void sendVerificationLink(String studentId, String email, String verificationLink) {

        // Instantiate a new RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        // Create a new StringRequest to send the verification link
        StringRequest stringRequest = new StringRequest(Request.Method.GET, verificationLink,
                // Define what to do when the response is received
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("response", response);
                        try {
                            // Parse the response JSON
                            JSONObject jsonObject = new JSONObject(response);
                            boolean activated = jsonObject.getBoolean("activated");
                            String activationError = jsonObject.getString("error");
                            Log.d("Activation", "Activation : " + activationError);
                            if (activated) {
                                // Account activated successfully
                                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                startActivity(intent);
                                Toast.makeText(getApplicationContext(), "success", Toast.LENGTH_SHORT).show();
                            } else {
                                // Account activation failed
                                Toast.makeText(getApplicationContext(), "The activation of the account failed.", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Log.d("Parsing", "Error : " + e);
                            Toast.makeText(getApplicationContext(), "There was an error parsing the data received from the server.", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                // Define what to do when there is an error
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "There was an error retrieving the data from the server.", Toast.LENGTH_SHORT).show();
                    }
                });

        // Add the StringRequest to the RequestQueue
        requestQueue.add(stringRequest);
    }
}

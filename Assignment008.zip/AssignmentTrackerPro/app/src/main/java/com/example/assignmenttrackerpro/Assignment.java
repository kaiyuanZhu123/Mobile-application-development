package com.example.assignmenttrackerpro;

public class Assignment {
    private String mName;
    private String mId;
    public Assignment(String name, String id) {
        mName = name;
        mId = id;
    }
    public String getName() {
        return mName;
    }
    public String getId() {
        return mId;
    }

    @Override
    public String toString(){
        return mName + " " + mId;
    }
}
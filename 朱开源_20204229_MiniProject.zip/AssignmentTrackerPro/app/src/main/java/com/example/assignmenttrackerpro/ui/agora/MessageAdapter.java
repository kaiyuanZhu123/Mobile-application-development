package com.example.assignmenttrackerpro.ui.agora;

import android.content.Context;
import android.graphics.Color;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.assignmenttrackerpro.R;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {
    private List<MessagePost> messageList;
    private LayoutInflater layoutInflater;
    private OnRecyclerItemLongListener mOnItemLong = null;
    private  static String userId;

    public MessageAdapter(List<MessagePost> messageList, Context context, String userId) {
        this.messageList = messageList;
        this.layoutInflater = LayoutInflater.from(context);
        this.userId = userId;
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = layoutInflater.inflate(R.layout.item_recycler_agora, parent, false);
        return new MessageViewHolder(itemView, null);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
        MessagePost currentMessage = messageList.get(position);
        holder.bind(currentMessage);
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }

    static class MessageViewHolder extends RecyclerView.ViewHolder implements View.OnLongClickListener{
        TextView textViewNewsTitle;
        TextView textViewNewsContent;
        TextView textViewTimestamp;
        CardView cardView;
        OnRecyclerItemLongListener mOnItemLong = null;

        public MessageViewHolder(@NonNull View itemView, OnRecyclerItemLongListener listener) {
            super(itemView);
            mOnItemLong = listener;
            textViewNewsTitle = itemView.findViewById(R.id.tv_news_title);
            textViewNewsContent = itemView.findViewById(R.id.tv_news_content);
            textViewTimestamp = itemView.findViewById(R.id.tv_timestamp);
            cardView = itemView.findViewById(R.id.card_view);
        }


        void bind(MessagePost message) {
            String deviceId = message.getDevice_id();
            if(deviceId.equals("356417092692090") || deviceId.equals("f57d14d926d22e14")){
                textViewNewsTitle.setText("teacher");
                cardView.setCardBackgroundColor(Color.YELLOW);
            }
            else if(deviceId.equals("robot")){
                textViewNewsTitle.setText("robot");
                cardView.setCardBackgroundColor(Color.GREEN);
            }
            else{
                if (userId.equals(deviceId)) {
                    cardView.setCardBackgroundColor(Color.parseColor("#D3D3D3"));
                } else {
                    cardView.setCardBackgroundColor(Color.WHITE);
                }

                if (deviceId.length() > 4) {
                    textViewNewsTitle.setText(secretDeviceID(deviceId));
                } else {
                    textViewNewsTitle.setText(deviceId);
                }
            }

            if(message.getMessage().startsWith("@" + secretDeviceID(Settings.Secure.ANDROID_ID))){
                cardView.setCardBackgroundColor(Color.parseColor("#A3E4D7"));
            }

            textViewNewsContent.setText(message.getMessage());

            long timestamp = Long.parseLong(message.getTimer_server()) * 1000L; // Assuming the timer server value is in seconds
            Date date = new Date(timestamp);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
            String formattedDate = dateFormat.format(date);

            Date currentDate = new Date();
            String formattedCurrentDate = dateFormat.format(currentDate);

            if (formattedDate.equals(formattedCurrentDate)) {
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
                String formattedTime = timeFormat.format(date);
                textViewTimestamp.setText("Today, " + formattedTime);
            } else {
                SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                String formattedDateTime = dateTimeFormat.format(date);
                textViewTimestamp.setText(formattedDateTime);
            }
        }

        @Override
        public boolean onLongClick(View v) {
            if(mOnItemLong != null){
                mOnItemLong.onItemLongClick(v,getPosition());
            }
            return true;
        }

        private String secretDeviceID(String deviceId){
            String shortenedDeviceId = deviceId.substring(0,2) + "###" + deviceId.substring(deviceId.length() - 3);
            return shortenedDeviceId;
        }
    }

    public interface OnRecyclerItemLongListener{
        void onItemLongClick(View view,int position);
    }
    public void setOnItemLongClickListener(OnRecyclerItemLongListener listener){
        this.mOnItemLong =  listener;
    }
}

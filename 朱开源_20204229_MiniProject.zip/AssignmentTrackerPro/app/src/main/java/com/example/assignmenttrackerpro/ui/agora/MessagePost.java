package com.example.assignmenttrackerpro.ui.agora;

public class MessagePost {
    private String device_id;
    private String ip_location;
    private String timer_device;
    private String timer_server;
    private String message;
    public MessagePost(String id, String ip, String time, String message){
        this.device_id = id;
        this.ip_location = ip;
        this.timer_device = time;
        this.message = message;
    }
    public MessagePost(String id, String ip, String timer_device, String timer_server, String message){
        this.device_id = id;
        this.ip_location = ip;
        this.timer_device = timer_device;
        this.timer_server = timer_server;
        this.message = message;
    }
    public void setDevice_id(String device_id){
        this.device_id = device_id;
    }
    public void setIp_location(String ip){
        this.ip_location = ip;
    }
    public void setTimer_device(String timer_device){
        this.timer_device = timer_device;
    }
    public void setTimer_server(String timer_server){
        this.timer_server = timer_server;
    }
    public void setMessage(String message){
        this.message = message;
    }
    public String getDevice_id(){
        return device_id;
    }
    public String getIp_location(){
        return ip_location;
    }
    public String getTimer_device(){
        return timer_device;
    }
    public String getTimer_server(){
        return timer_server;
    }
    public String getMessage(){
        return message;
    }
}
